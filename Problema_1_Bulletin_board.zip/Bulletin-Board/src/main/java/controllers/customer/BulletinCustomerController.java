/* BulletinCustomerController.java
 *
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the 
 * TDG Licence, a copy of which you may download from 
 * http://www.tdg-seville.info/License.html
 * 
 */

package controllers.customer;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.BulletinService;
import controllers.AbstractController;
import domain.Bulletin;

@Controller
@RequestMapping("/bulletin/customer")
public class BulletinCustomerController extends AbstractController {

	// Services ---------------------------------------------------------------

	@Autowired
	private BulletinService bulletinService;

	// Constructors -----------------------------------------------------------

	public BulletinCustomerController() {
		super();
	}

	// Listing ----------------------------------------------------------------

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Bulletin> bulletins;

		bulletins = bulletinService.findAllOrderByMomentDescending();
		result = new ModelAndView("bulletin/list");
		result.addObject("bulletins", bulletins);

		return result;
	}

	// Creation ---------------------------------------------------------------

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Bulletin bulletin;

		bulletin = bulletinService.create();
		result = createEditModelAndView(bulletin);

		return result;
	}

	// Edition ----------------------------------------------------------------

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam int bulletinId) {
		ModelAndView result;
		Bulletin bulletin;

		bulletin = bulletinService.findOne(bulletinId);
		Assert.notNull(bulletin);
		result = createEditModelAndView(bulletin);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid Bulletin bulletin, BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = createEditModelAndView(bulletin);
		} else {
			try {
				bulletinService.save(bulletin);
				result = new ModelAndView("redirect:list.do");
			} catch (Throwable oops) {
				result = createEditModelAndView(bulletin,
						"bulletin.commit.error");
			}
		}

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(Bulletin bulletin, BindingResult binding) {
		ModelAndView result;

		try {
			bulletinService.delete(bulletin);
			result = new ModelAndView("redirect:list.do");
		} catch (Throwable oops) {
			result = createEditModelAndView(bulletin, "bulletin.commit.error");
		}

		return result;
	}

	// Ancillary methods ------------------------------------------------------

	protected ModelAndView createEditModelAndView(Bulletin bulletin) {
		ModelAndView result;

		result = createEditModelAndView(bulletin, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(Bulletin bulletin,
			String message) {
		ModelAndView result;

		result = new ModelAndView("bulletin/edit");
		result.addObject("bulletin", bulletin);
		result.addObject("message", message);

		return result;
	}

}