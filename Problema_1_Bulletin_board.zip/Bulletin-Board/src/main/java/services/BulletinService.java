/*
 * BulletinService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.BulletinRepository;
import domain.Bulletin;

@Service
@Transactional
public class BulletinService {

	// Managed repository -----------------------------------------------------
	@Autowired
	private BulletinRepository	bulletinRepository;


	// Constructor ------------------------------------------------------------
	public BulletinService() {
		super();
	}

	// Simple CRUD methods------------------------------------------------
	public Bulletin create() {
		final Bulletin bulletin = new Bulletin();
		bulletin.setMoment(new Date());
		return bulletin;
	}

	public Bulletin findOne(final int bulletinId) {
		Bulletin result;

		result = this.bulletinRepository.findOne(bulletinId);
		Assert.notNull(result);

		return result;
	}

	public Bulletin save(final Bulletin bulletin) {
		Assert.notNull(bulletin);
		final Bulletin bulletinGuardado = this.bulletinRepository.saveAndFlush(bulletin);
		Assert.notNull(bulletinGuardado);

		return bulletinGuardado;

	}
	public void delete(final Bulletin bulletin) {
		Assert.notNull(bulletin);
		Assert.isTrue(bulletin.getId() != 0);
		this.bulletinRepository.delete(bulletin);
	}

	public Collection<Bulletin> findAll() {

		return this.bulletinRepository.findAll();

	}

	// Other business Methods -----------------------------------------

	public Collection<Bulletin> findAllOrderByMomentDescending() {
		return this.bulletinRepository.findAllOrderByMomentDescending();
	}

}
