/*
 * BulletinServiceTest.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Bulletin;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class BulletinServiceTest extends AbstractTest {

	// Service under test ---------------------------------

	@Autowired
	private BulletinService	bulletinService;


	// Tests ----------------------------------------------

	@Test
	public void testCreatePositive() {

		final Bulletin bulletin = this.bulletinService.create();
		bulletin.setTitle("title 10");
		bulletin.setText("texto 10");

		bulletin.setAuthor("Author 10");

	}
	@Test
	public void testSavePositive() {
		final Bulletin bulletin1 = this.bulletinService.create();
		bulletin1.setTitle("Title 7");
		bulletin1.setAuthor("Author 7");

		bulletin1.setText("Text 7");
		final Bulletin bulletin2 = this.bulletinService.save(bulletin1);

		final List<Bulletin> bulletins = new ArrayList<Bulletin>();
		bulletins.addAll(this.bulletinService.findAllOrderByMomentDescending());

		Assert.isTrue(bulletins.contains(bulletin2));

	}

	@Test(expected = ConstraintViolationException.class)
	public void testSaveNegative() {
		final Bulletin bulletin1 = this.bulletinService.create();

		bulletin1.setAuthor("Author 7");

		bulletin1.setText("Text 7");
		final Bulletin bulletin2 = this.bulletinService.save(bulletin1);

		final List<Bulletin> bulletins = new ArrayList<Bulletin>();
		bulletins.addAll(this.bulletinService.findAllOrderByMomentDescending());

		Assert.isTrue(bulletins.contains(bulletin2));

	}
	@Test
	public void testDeletePositive() {

		final Bulletin bulletin = this.bulletinService.create();
		bulletin.setTitle("Title 8");
		bulletin.setAuthor("Author 8");

		final Date fecha = new Date(System.currentTimeMillis() - 1);
		bulletin.setMoment(fecha);

		bulletin.setText("Text 8");

		final Bulletin bulletin1 = this.bulletinService.save(bulletin);

		this.bulletinService.delete(bulletin1);

		final List<Bulletin> bulletins = new ArrayList<Bulletin>();
		bulletins.addAll(this.bulletinService.findAllOrderByMomentDescending());

		Assert.isTrue(!bulletins.contains(bulletin1));

	}

	@Test(expected = IllegalArgumentException.class)
	public void testDeleteNegative() {

		final Bulletin bulletin = this.bulletinService.create();
		bulletin.setTitle("Title 9");
		bulletin.setAuthor("Author 9");

		final Date fecha = new Date(System.currentTimeMillis() - 1);
		bulletin.setMoment(fecha);

		bulletin.setText("Text 9");

		this.bulletinService.delete(bulletin);

		final List<Bulletin> bulletins = new ArrayList<Bulletin>();
		bulletins.addAll(this.bulletinService.findAllOrderByMomentDescending());

	}
}
